char *** ligne_commande (int * flag, int *nb);
void affiche (char ***t);
void libere (char ***t);
